import cv2
import numpy as np
from os import name, system

def read_image(image_name):
    image = cv2.imread(image_name)
    return image

def break_into_grids(image, grids = 3):
    w, h, _ = image.shape
    gridw, gridh = w//3, h//3
    g = {}
    
    for r in range(grids):
        for c in range(grids):
            x1 = r * gridw
            x2 = x1 + gridw
            y1 = c * gridh
            y2 = y1 + gridh
            g[f'{r}{c}'] = image[x1:x2, y1:y2]    
    return g

def make_image_from_grids(image_grids, grid_list):
    
    grid0, grid1, grid2 = image_grids[grid_list[0]], image_grids[grid_list[1]], image_grids[grid_list[2]] 
    row_image = cv2.hconcat([grid0, grid1, grid2])
    for c in range(3, 9, 3):
        grid0, grid1, grid2 = image_grids[grid_list[c]], image_grids[grid_list[c+ 1]], image_grids[grid_list[c+ 2]] 
        col_image = cv2.hconcat([grid0, grid1, grid2])
        row_image = cv2.vconcat([row_image, col_image])
    
    h, w, _ = row_image.shape
    cv2.line(row_image, (0, h//3), (w, h//3), color= (0, 255, 0), thickness= 1, lineType= cv2.LINE_4)
    cv2.line(row_image, (0, 2*h//3), (w, 2*h//3), color= (0, 255, 0), thickness= 1, lineType= cv2.LINE_4)
    
    cv2.line(row_image, (w//3, 0), (w//3, h), color= (0, 255, 0), thickness= 1, lineType= cv2.LINE_4)
    cv2.line(row_image, (2*w//3, 0), (2*w//3, h), color= (0, 255, 0), thickness= 1, lineType= cv2.LINE_4)
    
    cv2.imwrite("Generated.jpg",row_image)
    return row_image


def compare_images(original_grid, user_grid):
    for g1, g2 in zip(original_grid, user_grid):
        if g1 != g2:
            return False
    return True

def clear_screen():
    if name == 'nt':
        system('cls')
    else:
        system('clear')