import cv2
import numpy as np
from arrange import read_image, make_image_from_grids
from arrange import break_into_grids, compare_images, clear_screen
import random
from os import system, name
from colorama import Fore, Style

grids = 3
image_names = ['Jupiter.jpg', 'nebula.jpg', 'pillar.jpg', 'Star birth.jpg', ]
image_name = random.choice(image_names)
image = read_image(image_name)
image_grids = break_into_grids(image)

original_grid_dict = image_grids.copy()

initial_grid_list = list(set(image_grids.keys()))
generated_image = make_image_from_grids(image_grids, initial_grid_list)

if name == 'nt':
    system('cls')
    system("Generated.jpg")
else:
    system('clear')
    system("xdg-open Generated.jpg")

while True:
        
    grid_list = []
    grid_count = 0
    
    lines = '''
    Please provide the new grid number you want to assign to the current grid cell image. 
    Enter grid numbers for each row, separated by spaces. For example, input the numbers like this: 00 01 02.
    '''
    print(f"{Fore.LIGHTYELLOW_EX} {lines.upper()}{Style.RESET_ALL}")
    
    while grid_count < grids:
        u_input = input(f"Enter the numbers for row {grid_count}: ")
        u_input = u_input.split()
        
        if len(u_input) > grids:
            print(f"{Fore.RED} Each row consists of only {grids} grids {Style.RESET_ALL}")
            continue
        grid_list.extend(u_input)
        grid_count += 1
        
    if len(grid_list) > len(set(grid_list)):
        print(f"{Fore.LIGHTRED_EX} You have entered incorrect grid values")
        continue
    
    if grid_list == list(original_grid_dict.keys()):
        print(f"{Fore.LIGHTRED_EX} You have entered grid numbers to get the same image")
        continue
        
    checker = compare_images(initial_grid_list, grid_list)
    user_image = make_image_from_grids(image_grids, grid_list)
    initial_grid_list = grid_list.copy()
    
    if checker:
        print(f"{Fore.BLUE} YOU HAVE SOLVED THE PUZZLE! {Style.RESET_ALL}")
        h, w, _ = image.shape
        cv2.line(image, (0, h//3), (w, h//3), color= (0, 255, 0), thickness= 1, lineType= cv2.LINE_4)
        cv2.line(image, (0, 2*h//3), (w, 2*h//3), color= (0, 255, 0), thickness= 1, lineType= cv2.LINE_4)
        
        cv2.line(image, (w//3, 0), (w//3, h), color= (0, 255, 0), thickness= 1, lineType= cv2.LINE_4)
        cv2.line(image, (2*w//3, 0), (2*w//3, h), color= (0, 255, 0), thickness= 1, lineType= cv2.LINE_4)
        cv2.imwrite("Generated.jpg", image)
        exit()
    
    clear_screen()
        
    print(f"{Fore.RED} INCORRECT SOLUTION, TRY AGAIN {Style.RESET_ALL}")