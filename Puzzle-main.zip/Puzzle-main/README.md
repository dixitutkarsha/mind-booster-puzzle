# Puzzle

## To run the code
```
git clone https://github.com/Chandrahas-B/Puzzle.git
cd Puzzle
```

#### Using conda:
```
conda env create -f environment.yml
```
#### Using pip:
```
pip install -r requirements.txt
```
